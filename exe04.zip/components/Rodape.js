import React from 'react'


const Rodape = () => {
  return (
    <>
      <div style={{width: '100%'}} className='bg-secondary text-light text-center position-fixed bottom-0'>
        <h1>Rodapé</h1>
      </div>
    </>
  )
}

export default Rodape